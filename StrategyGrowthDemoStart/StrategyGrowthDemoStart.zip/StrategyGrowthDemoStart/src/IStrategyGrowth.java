/**
 * Step 2: Create the interface
 * <p>
 * Created by WilsonWong on 3/28/2018.
 */


public interface IStrategyGrowth {
    public double run(double value);
}